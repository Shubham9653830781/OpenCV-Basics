# Contour Detection

import cv2
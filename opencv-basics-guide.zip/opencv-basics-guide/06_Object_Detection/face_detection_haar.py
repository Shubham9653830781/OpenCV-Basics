# Face Detection using Haar Cascades

import cv2
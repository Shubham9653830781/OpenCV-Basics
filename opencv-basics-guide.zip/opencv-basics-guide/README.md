# OpenCV Basics Guide

This repository provides a structured introduction to OpenCV for beginners.

# Mask Specific Colors

import cv2
# Introduction to OpenCV

Learn what OpenCV is and how to get started.
# Basic OpenCV Operations

import cv2
import numpy as np
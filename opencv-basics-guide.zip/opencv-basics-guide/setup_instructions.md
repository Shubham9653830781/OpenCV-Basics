# Setup Instructions

Follow these steps to install OpenCV and run the examples.

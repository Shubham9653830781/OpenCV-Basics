# Reference Links

- https://docs.opencv.org
- https://learnopencv.com
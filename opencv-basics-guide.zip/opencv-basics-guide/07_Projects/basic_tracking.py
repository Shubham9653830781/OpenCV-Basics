# Basic Object Tracking

import cv2
# Virtual Paint Application

import cv2
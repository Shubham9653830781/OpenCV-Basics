# Face Blur on Video

import cv2
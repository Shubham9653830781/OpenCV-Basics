# Read from Webcam

import cv2
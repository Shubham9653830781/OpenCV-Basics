# Handling Mouse Events

import cv2
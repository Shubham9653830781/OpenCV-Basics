# Drawing Shapes and Text

import cv2
# Grayscale, Blur, and Edge Detection

import cv2